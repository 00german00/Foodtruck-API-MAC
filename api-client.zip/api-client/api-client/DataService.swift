//
//  DataService.swift
//  api-client
//
//  Created by German Fondevila on 3/25/17.
//  Copyright © 2017 German Fondevila. All rights reserved.
//

import Foundation

//create a delegate protocol so once we load our reviews and trucks we are going to call our Delagate and  anything that conforms to this will allow us to fire some methods. In our main view we are going to have all the trucks loaded and by calling trucksLoaded we can reload the trucks for example
protocol DataServiceDelegate: class {    
    func trucksLoaded()
    func reviewsLoaded()
}


class DataService {
    //by making it static qwe can just call instance from anywhere in the application by calling the class DataService.instance
    static let instance = DataService()
    
    weak var delegate: DataServiceDelegate?
    var foodTrucks = [FoodTruck]()
    var reviews = [FoodTruckReview]()
    
    
    ///////GET all food trucks    ////////////
    func getAllFoodTrucks() {
        let sessionConfig = URLSessionConfiguration.default
        
        // Create session, and optionally set a URLSessionDelegate
        let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
        // Create the request
        // Get all foodtrucks (GET /api/v1/foodtruck)
        guard let URL = URL(string: GET_ALL_FT_URL) else { return }  //if this fails is going to kick us out and return
        var request = URLRequest(url: URL)
        request.httpMethod = "GET"
        
        let task = session.dataTask(with: request, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) -> Void in
            if (error == nil) {
                //Success
                let statusCode = (response as! HTTPURLResponse).statusCode
                print("URL Session Task Succeeded: HTTP \(statusCode)")
                if let data = data {
                    self.foodTrucks = FoodTruck.parseFoodTruckJSONData(data: data)
                    self.delegate?.trucksLoaded()
                }
            }
            else {
                //Failure
                print("URL Session Task Failed \(error!.localizedDescription)")
            }
        })
        task.resume()
        session.finishTasksAndInvalidate()
        
        ////////GET all  reviews for a specific truck   /////////
        func getAllReviews(for truck: FoodTruck) {
            let sessionConfig = URLSessionConfiguration.default
        
            let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
        
            guard let URL = URL(string: "\(GET_ALL_FT_Reviews)/\(truck.id)") else { return }
            var request = URLRequest(url: URL)
            request.httpMethod = "GET"
        
            let task = session.dataTask(with: request, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) -> Void in
                if (error == nil) {
                    //Success
                    let statusCode = (response as! HTTPURLResponse).statusCode
                    print("URL Session Task Succeeded: HTTP \(statusCode)")
                    //Parse JSON data
                    if let data = data {
                        self.reviews = FoodTruckReview.parseReviewkJSONData(data: data)
                        self.delegate?.reviewsLoaded()
                    }
                }
                else {
                    //Failure
                    print("URL Session Task Failed \(error?.localizedDescription)")
                }
            })
            task.resume()
            session.finishTasksAndInvalidate()
        }
        
        
        
        // POST a new foodtruck
        func addNewFoodTruck(_ name: String, foodtype: String, avgcost: Double, latitude: Double, longitude: Double, completion: @escaping callback) {
            
            // Construct our JSON
            let json: [String: Any] = [
             "name": name,
             "foodtype": foodtype,
             "avgcost": avgcost,
             "geometry": [
                "coordinates": [
                    "lat": latitude,
                    "long": longitude
                    ]
                ]
            ]
            
            do {
                 // Serialize JSON
                let jsonData = try JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
                
                let sessionConfig = URLSessionConfiguration.default
                
                let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)

                guard let URL = URL(string: POST_ADD_NEW_TRUCK) else { return }
                var request = URLRequest(url: URL)
                request.httpMethod = "POST"

                // This is in the AuthService file and guard that the token exists otherwise notify
                guard let token = AuthService.instance.authToken else {
                    completion(false)
                    return
                }
                
                request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")  //just like in POSTMAN
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")  // just like in POSTMAN
                
                request.httpBody = jsonData     // we pass the serialized json from a few rows above as part of the httpBody
                
                let task = session.dataTask(with: request, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if (error == nil) {
                        //Success
                        // Check for status code 200 and if it's not 200 the authentication was not successful
                        let statusCode = (response as! HTTPURLResponse).statusCode
                        print("URL Session Task Succeeded: HTTP \(statusCode)")
                        
                        if statusCode != 200 {
                            completion(false)
                            return
                        } else {
                            self.getAllFoodTrucks()
                            completion(true)            // if we get a 200 we have competed the action
                        }
                    } else {
                        //Failure
                        print("URL Session Task Failed \(error?.localizedDescription)")
                        completion(false)
                    }
                })
                task.resume()
                session.finishTasksAndInvalidate()
                
            } catch let err {
                completion(false)
                print(err)
            }
            
        }
        
        // POST a new foodtruck Review
        func addNewReview(_ foodTruckId: String, title: String, text: String, completion: @escaping callback) {
            
            // Construct our JSON
            let json: [String: Any] = [
                "title": title,
                "text": text,
                "foodtruck": foodTruckId
            ]
            
            do {
                // Serialize JSON
                let jsonData = try JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
                let sessionConfig = URLSessionConfiguration.default
                let session = URLSession(configuration: sessionConfig, delegate: nil, delegateQueue: nil)
                guard let URL = URL(string:"\(POST_ADD_NEW_REVIEW)/\(foodTruckId)") else { return }
                var request = URLRequest(url: URL)
                request.httpMethod = "POST"
                // This is in the AuthService file and guard that the token exists otherwise notify
                guard let token = AuthService.instance.authToken else {
                    completion(false)
                    return
                }
                
                request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")  //just like in POSTMAN
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")  // just like in POSTMAN
                
                request.httpBody = jsonData     // we pass the serialized json from a few rows above as part of the httpBody
                
                let task = session.dataTask(with: request, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if (error == nil) {
                        //Success
                        // Check for status code 200 and if it's not 200 the authentication was not successful
                        let statusCode = (response as! HTTPURLResponse).statusCode
                        print("URL Session Task Succeeded: HTTP \(statusCode)")
                        
                        if statusCode != 200 {
                            completion(false)
                            return
                        } else {
                            //self.getAllFoodTrucks()   we don't call this here because the way the application is set up you need to go to a
                            // different screen to get to another review
                            completion(true)            // if we get a 200 we have competed the action
                        }
                    } else {
                        //Failure
                        print("URL Session Task Failed \(error!.localizedDescription)")
                        completion(false)
                    }
                })
                task.resume()
                session.finishTasksAndInvalidate()
                
            } catch let err {
                completion(false)
                print(err)
            }
        }
    }
}
