//
//  Foodtruck.swift
//  api-client
//
//  Created by German Fondevila on 3/25/17.
//  Copyright © 2017 German Fondevila. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit

class FoodTruck: NSObject, MKAnnotation {
    var id: String = ""
    var name: String = ""
    var foodType: String = ""
    var avgCost: Double = 0.0
    var geomType: String = "Point"
    var lat: Double = 0.0
    var long: Double = 0.0
    
    // we use the follofing objects of Objective C because they part of the MKAnnotation so the class Foodtruck conforms to the MKAnntation and we can take the latitude and longitude and drop pins on a map. And when clicking on the PIN you can see a title and a subtitle
    @objc var title: String?   // String? means it's optional
    @objc var subtitle: String?
    
    @objc var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: self.lat, longitude: self.long)
    }
    
    //static means you can call this function on this class and not a specific instance of this class, so basically we're calling on a specific foodtruck
    static func parseFoodTruckJSONData(data: Data) -> [FoodTruck] {
        //array of type FooTruck
        var foodtrucks = [FoodTruck]()
        
        // we wrapp it up here in case there's an error
        do {
            let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
        
            //Parse JSON Data
            if let trucks = jsonResult as? [Dictionary<String, AnyObject>] {
                for truck in trucks {
                    
                    let newTruck = FoodTruck()
                    newTruck.id = truck["_id"] as! String
                    newTruck.name = truck["name"] as! String
                    newTruck.foodType = truck["foodtype"] as! String
                    newTruck.avgCost = truck["avgcost"] as! Double
                    
                    // our gepmetry is a nested object in our json model so we need to pull it out
                    // PULL OUT INFO FROM A NESTED JSON OBJECT
                    let geometry = truck["geometry"] as! Dictionary<String, AnyObject>
                    newTruck.geomType  = geometry["type"] as! String
                    let coords = geometry["coordinates"] as! Dictionary<String, AnyObject>
                    newTruck.lat = coords["lat"] as! Double
                    newTruck.long = coords["long"] as! Double
                    
                    newTruck.title = newTruck.name
                    newTruck.subtitle = newTruck.foodType
                    
                    foodtrucks.append(newTruck)
                }
            }
        
        } catch let err {
            print(err)
        }
        return foodtrucks
    }
}
